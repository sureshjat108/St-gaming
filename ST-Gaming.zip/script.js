
const scriptURL = 'https://script.google.com/macros/s/AKfycbzYWZIdPxtAIqdzGpZE47jUAPmumy1j9QZi1iMFyQA/exec';
const form = document.getElementById('tournamentForm');
const response = document.getElementById('response');

form.addEventListener('submit', e => {
  e.preventDefault();
  const formData = new FormData(form);
  const data = Object.fromEntries(formData.entries());

  fetch(scriptURL, {
    method: 'POST',
    body: JSON.stringify(data)
  })
  .then(res => res.text())
  .then(txt => response.textContent = txt)
  .catch(err => response.textContent = 'Error: ' + err);
});
