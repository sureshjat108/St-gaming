
function doPost(e) {
  const sheet = SpreadsheetApp.openById('1dTLG6YsDecJTqVYaM3mXGxauadywUlXF1cOXWrObmtE').getSheetByName('Sheet1');
  const data = JSON.parse(e.postData.contents);

  sheet.appendRow([
    data.uid,
    data.name,
    data.whatsapp,
    data.screenshot,
    data.tournament,
    data.date
  ]);

  return ContentService.createTextOutput('Success').setMimeType(ContentService.MimeType.TEXT);
}
